<?php

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'if042994517_wp700' );

/** Database username */
define( 'DB_USER', '42994517_3' );

/** Database password */
define( 'DB_PASSWORD', '6!(p1CS6R4' );

/** Database hostname */
define( 'DB_HOST', 'sql207.byetcluster.com' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'rxh6jgjzgiq9bn5peeslc9jxw91ejqiuylnxav0gagifsoyt6ksad8rar3dalmet' );
define( 'SECURE_AUTH_KEY',  'y6e3efmxpnolmbji3sip3r3ih9l3relrpu7mlvw89rn0qmmkewyzq4eoltqztt9e' );
define( 'LOGGED_IN_KEY',    's1cjqedaqadhvqd6wwdci4wdm6o3boczlu4ns9adzpsjcpzcepdyby9lsl39ycly' );
define( 'NONCE_KEY',        '7nqbl0u0vj0nfaqglrww4mhcylkmsau8x41fjugpvxglydpubwx1sw2dg33en8vo' );
define( 'AUTH_SALT',        'fdn8wxgjw3th2gotec98h0blsms7uksa82wivqy9rsnopvul4oswyac1fhaktgqc' );
define( 'SECURE_AUTH_SALT', 'al9wmnxynuewqnuarqxs2pildkm1lrzlayxcjnjlwj6laq8syhdpu2rewvbkccor' );
define( 'LOGGED_IN_SALT',   'ftwejqypp3jzpvcwztc5znv5rbrxqg0q515gjequijhr1juhxpw51iht907dqrez' );
define( 'NONCE_SALT',       'hspo55u9wmrc2tlcquihs6ehe1v9c1sxhsl6ra7fmt5s5al1os9umzw3yts0vb20' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wpns_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



define('WPFC_CLEAR_CACHE_AFTER_THEME_UPDATE', true);
define('WP_MEMORY_LIMIT', '768M');
define('WP_MAX_MEMORY_LIMIT', '768M');

define('WPFC_CLEAR_CACHE_AFTER_PLUGIN_UPDATE', true);
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
